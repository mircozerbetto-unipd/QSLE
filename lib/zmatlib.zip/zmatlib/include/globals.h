#ifndef GLOBALS_H
#define GLOBALS_H


#define MIN(a, b) ((a) < (b) ? a : b)
#define SLOP_FACTOR 0.45
#define RAD2DEG (180.0 / M_PI)


#endif
