#ifndef ZMAT_H
#define ZMAT_H

#include "globals.h"
#include "types.h"
#include "molecule.h"

#include "config.h"

#endif
